package ir.edusa.parents.Models;

public class CommandMessage extends Command {
    private String Command_Data;


    public CommandMessage() {
    }

    public String getCommand_Data() {
        return Command_Data;
    }

    public void setCommand_Data(String command_Data) {
        Command_Data = command_Data;
    }
}
