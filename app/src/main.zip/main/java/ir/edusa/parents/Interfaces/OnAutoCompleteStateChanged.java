package ir.edusa.parents.Interfaces;

public interface OnAutoCompleteStateChanged {
    public void onProgressBarVisibityChange(boolean visible);
}
