package ir.edusa.parents.Interfaces;

import ir.edusa.parents.Models.DestinationPoint;

public interface OnDestinationPointClickListener {
    public void onItemSelect(DestinationPoint destinationPoint);
}
