package ir.edusa.parents.Interfaces;

import ir.edusa.parents.Models.AlarmLocationPoint;

public interface OnAlarmPointClickListener {
    public void onItemSelect(AlarmLocationPoint point);
    public void onItemDelete(AlarmLocationPoint point);
}
