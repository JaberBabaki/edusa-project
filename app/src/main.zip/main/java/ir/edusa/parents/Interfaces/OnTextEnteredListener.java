package ir.edusa.parents.Interfaces;

import ir.edusa.parents.Models.SchoolService;

public interface OnTextEnteredListener {
    public void onSubmit(String s, SchoolService service);
}
