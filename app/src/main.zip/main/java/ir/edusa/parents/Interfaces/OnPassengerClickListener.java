package ir.edusa.parents.Interfaces;

import ir.edusa.parents.Models.Passenger;

public interface OnPassengerClickListener {
    public void onItemSelect(Passenger passenger);
}
