package ir.edusa.parents.Interfaces;

import ir.edusa.parents.Models.SchoolService;

public interface OnAbsenceDatePickedListener {
    public void onPick(String date, int direction, SchoolService service);

}
