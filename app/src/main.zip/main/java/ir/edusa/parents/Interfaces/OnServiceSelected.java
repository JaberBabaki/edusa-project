package ir.edusa.parents.Interfaces;

import ir.edusa.parents.Models.SchoolService;

public interface OnServiceSelected {
    public void onItemSelect(SchoolService service);

}
